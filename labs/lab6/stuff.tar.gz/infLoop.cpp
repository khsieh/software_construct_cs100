using namespace std;

int main(){
    int i = 0;
    while(i == 0){
        continue;
    }
    return 0;
}

my_shell now works for the following:
I/O Redirection
Background Jobs
^C signal handling
Path finding
also includes a typescript for my_shell

